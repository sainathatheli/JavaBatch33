package com.training;

public class ExampleOnStr2 {
	public static void main(String[] args) {

     String s="hello"; //String literal
     
     String s1= new String("hello"); //String Object
     
     String s2="hello";
     
     String s3= new String("hello");
     
     System.out.println(s==s1); //false
     
     System.out.println(s.equals(s1));//true
     
     System.out.println(s==s2); //true =>comparing two literals
     
     System.out.println(s1==s3); //false =>comparing two String Objects
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     


	}
}
