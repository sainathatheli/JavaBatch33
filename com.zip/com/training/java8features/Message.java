package com.training.java8features;

public class Message {
	 public Message(String msg){  
	        System.out.print(msg);  
	    } 
}
