package com.training;

public class ExampleOnContinue {

	public static void main(String[] args) {
   //skip the fifth iteration and continue the next iteration
		
		 int i=1; //initialization
		   while(i<=10) {
			   if(i==5) {//here skipping the fifth iteration and continue to next 
				   i+=1;
				   continue;
			   }
			   System.out.println(i);
			   i+=1; //i=i+1;
		   }
		
	}


}
