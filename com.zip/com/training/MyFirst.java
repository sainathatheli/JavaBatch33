package com.training;

public interface MyFirst {
	static final int a=10;
    public String sayHello();
    void methodOne();
    public abstract void methodTwo();
	
}
