package com.training;

import java.util.Scanner;

public class ExampleOnArray6 {

	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
		
	  int a[][] =new int[3][3];
		
	  //insert the values for array a[r][c]
	  
	  for(int i=0;i<3;i++) {
		  for(int j=0;j<3;j++) {
			  
            System.out.println("Enter the elements for a[][]");
			a[i][j]=s.nextInt();  
		  }		  
	  }	  
	//     display the element using for loop
		System.out.println("Elements are :");
	  for(int i=0;i<3;i++){ //rows
		  for(int j=0;j<3;j++){ //columns   
 	       System.out.print(a[i][j]+" ");  
	     }
	       System.out.println("");
	    }		
	}
  }