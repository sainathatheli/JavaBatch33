package com.training.keyword;

public class ExampleOnFinalKeyword {
	
	final int courseCode=1001;
	static final String collegeName="XYZ";
	final  float pi;
	static final String dressCode;
	{//instance block
		pi=3.142f;
		System.out.println("instance block:"+this.pi);
	}
	
	static {//static block
		dressCode="YES";
		System.out.println("we are in static block : "+ExampleOnFinalKeyword.dressCode);
	}

	public static void main(String[] args) {
		ExampleOnFinalKeyword eofk = new ExampleOnFinalKeyword();
	     System.out.println(eofk.courseCode);
	     System.out.println(ExampleOnFinalKeyword.collegeName);
	     
		
		
		
	}
	
}
