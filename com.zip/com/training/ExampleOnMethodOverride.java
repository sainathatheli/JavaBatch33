package com.training;

public class ExampleOnMethodOverride {

	public void methodOne() {
		System.out.println("we are in methodOne of ExampleOnMethodOverride");
	}
	
	public void methodTwo() {
		System.out.println("we are in methodTwo of ExampleOnMethodOverride");
	}
}
