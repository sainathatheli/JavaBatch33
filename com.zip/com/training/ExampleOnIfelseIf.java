package com.training;

import java.util.Scanner;

public class ExampleOnIfelseIf {

	public static void main(String[] args) {
	    Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter the first number : ");
		int a=sobj.nextInt();
		
		System.out.println("Enter the second number : ");
		int b=sobj.nextInt();
		
		System.out.println("Enter the third number : ");
		int c=sobj.nextInt();
		
		if((a>b) && (a>c)) {
			System.out.println("a is greater than b,c");
		}else if(b>c && b>a) {
			System.out.println("b is greater than a,c");
			
		}else {
			System.out.println("c is greater than a,b");
		}
		
	
	}
	
	
}
