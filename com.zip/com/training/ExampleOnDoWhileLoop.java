package com.training;

public class ExampleOnDoWhileLoop {

	
	
	public static void main(String[] args) {
		
		int i=1;
		do {
			System.out.println(i);
			i+=1;
		}while(i<=10);
		
		
		System.out.println("----------------******----------------");
		
		int j=1,n=4;
		do {
			System.out.println(n+"X"+j+"="+(n*j));
			j+=1;
		}while(j<=10);
		
	}
	
	
}
