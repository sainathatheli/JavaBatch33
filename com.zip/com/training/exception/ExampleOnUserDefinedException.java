package com.training.exception;

import java.util.Scanner;

public class ExampleOnUserDefinedException {
    
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		try {
		System.out.println("Enter the age : ");
		int age=sc.nextInt();
		
		if(age<18) {
			throw new MyException("Age should be 18 or greater than 18 to caste a vote");
		}else {
			System.out.println("valid age to vote");
		}
		
		}catch (MyException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		
		
		
		
	}

	
	
}
