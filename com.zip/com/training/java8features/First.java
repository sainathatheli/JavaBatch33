package com.training.java8features;

@FunctionalInterface
public interface First { 
	
	public abstract void display(); //single abstract method(SAM) we can apply lambda expression
	

}
