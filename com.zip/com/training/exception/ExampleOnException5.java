package com.training.exception;

public class ExampleOnException5 {

	public static void main(String[] args) {
		
		int a=10;
		
		if(a<5) {
			throw new ArithmeticException("explicitly throwing built-in exception using throw");
		}
		
		System.out.println(a);
		
		
	}
}
