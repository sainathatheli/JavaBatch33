package com.training.keyword;

public class Test {
	   public static void main(String[] args) { 
		ExamOnAccessModfiers eoaf = new ExamOnAccessModfiers(); 
		System.out.println(eoaf.a);
		//System.out.println(eoaf.b); 
		System.out.println(eoaf.name);
		System.out.println(eoaf.pi);

			eoaf.methodOne(); 
			//eoaf.methodTwo(); 
			eoaf.methodThree(); 
			eoaf.methodFour();


	}

}
