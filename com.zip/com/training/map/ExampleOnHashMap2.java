package com.training.map;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import com.training.set.Student;

public class ExampleOnHashMap2 {
   //Here we are storing student object as value
	
	public static void main(String[] args) {
		
		Map<Integer,Student> hm = new LinkedHashMap<Integer,Student>();
		
		Student s1 = new Student(301,"martin","boston");
		Student s2 = new Student(290,"john","Newjersey");
		Student s3 = new Student(302,"rahul","India");
		Student s4 = new Student(291,"allen","Aust");
		
		hm.put(2,s1);
		hm.put(1,s2);
		hm.put(3,s3);
		hm.put(4, s4);
		
		System.out.println(hm);
		
		//get the student object based on key
		 Student sobj =hm.get(2);
		 System.out.println("Student details based on key");
		 System.out.println(sobj.getStudId()+" "+sobj.getStudName()+" "+sobj.getAddress());
		 
		 //get the Only the values
		Collection<Student> sobj1= hm.values();
		System.out.println("");
		System.out.println("Student details are");
		for(Student s:sobj1) {
			System.out.println(s.getStudId()+" "+s.getStudName()+" "+s.getAddress());
		}
		
		
	}
	
	
	
	
	
	
}
