package com.training.keyword;

public final class First {

	public int getSum(int x,int y) {
		return x+y;
	}
	
	public final void methodOne() {
		System.out.println("we are in methodOne");
	}
	
}
