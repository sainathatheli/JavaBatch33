package com.training.set;

import java.util.Objects;

public class Student {
   
	private int studId;
	private String studName;
	private String address;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studId, String studName, String address) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.address = address;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public int hashCode() {
		return Objects.hash(address, studId, studName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(address, other.address) && studId == other.studId
				&& Objects.equals(studName, other.studName);
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", address=" + address + "]";
	}

	
	
}
