package com.training;

public class C extends B{

	public void methodThree() {
		System.out.println("we are in methodThree of C claa");
		
	}
	
	public static void main(String[] args) {
		C c = new C();
		c.methodOne();
		c.methodTwo();
		c.methodThree();
		
	}
	
}
