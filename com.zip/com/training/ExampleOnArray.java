package com.training;

public class ExampleOnArray{
	 
	   public static void main(String args[]){
	  
	    //declare and initializtion of array;

	      int a[] = {10,20,30,40,50};

	     System.out.println(a);
	   
	     System.out.println(a.length);//no of elements in array is  5

	    //using for loop
	      
	     for(int i=0;i<a.length;i++){

	         System.out.println(a[i]);

	      } 
	    //for each loop
	   
	      for(int b : a){ //here we are storing array object  a  into b

	      System.out.println("displaying the elements using for each loop "+b);    

	      }
	   }

	}
