package com.training;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.bean.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
 
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    	
    	Product p=context.getBean("produtObj",Product.class);
   
    	System.out.println(p);
    	
    	List<String> al=p.getData();
    	System.out.println("Collection Injection from list");
    	al.forEach(System.out::println);
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
}
