package com.training;

public class ExampleOnInterface2 implements M1,M2{

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodTwo");
	}

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodOne");
	}

	public static void main(String[] args) {
		ExampleOnInterface2 eof2 = new ExampleOnInterface2();
		eof2.methodOne();
		eof2.methodTwo();
		
	}
	
}
