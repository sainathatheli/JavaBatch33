package com.training.restcontroller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")
public class EmployeController {
	
	@GetMapping("/hello")
	public String sayHello() { //htttp:localhost:portno/projectname/emp/hello
		return "welcome to springboot restapi services";
	}
	
	@PostMapping("/h1")
	public String ex2() { //htttp:localhost:portno/projectname/emp/h1
		return "welcome to springboot restapi services we are in ex2 postmapping";
	}
	

	@PutMapping("/h2")
	public String ex3() { //htttp:localhost:portno/projectname/emp/h2
		return "welcome to springboot restapi services we are in ex3 putmapping";
	}
	
	
	@DeleteMapping("/h3")
	public String ex4() { //htttp:localhost:portno/projectname/emp/h3 -end point url
		return "welcome to springboot restapi services we are in ex4 Deletemapping";
	}
}
