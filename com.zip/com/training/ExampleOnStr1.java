package com.training;

public class ExampleOnStr1 {
    public static void main(String[] args) {
		
    	String s ="hello";
    	
    	System.out.println(s.hashCode()+" "+s);
    	
    	s=s.concat(" world");
    	
       System.out.println(s.hashCode()+" "+s);
    	
    	
    	
    	
	}
}
