package com.training.map;

import java.util.Collection;
import java.util.Comparator;
import java.util.TreeMap;
import java.util.Map;

import com.training.set.Student;

public class ExampleOnTreeMap3 {
   //Here we are storing student object as value
	
	public static void main(String[] args) {
		
		Map<Student,Integer> hm = new TreeMap<Student,Integer>(new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				int id1=o1.getStudId();
				int id2=o2.getStudId();
				if(id1<id2) {
					return -1;
				}else if(id1>id2){
					return 1;
				}else {
					return 0;
				}
			}
			
		});
		
		Student s1 = new Student(301,"martin","boston");
		Student s2 = new Student(290,"john","Newjersey");
		Student s3 = new Student(302,"rahul","India");
		Student s4 = new Student(291,"allen","Aust");
		
		hm.put(s1,1);
		hm.put(s2,2);
		hm.put(s3,3);
		hm.put(s4,4);
		
		
		System.out.println(hm);
		
		
		
		
	}
	
	
	
	
	
	
}
