package com.training.set;


import java.util.Iterator;
import java.util.TreeSet;

public class ExampleOnTreeSet {

	public static void main(String[] args) {
		
		TreeSet<Integer> ts = new TreeSet<Integer>();
		   
		  ts.add(13);
		     ts.add(5);
		     ts.add(20);
		     ts.add(15);
		     ts.add(10);
		     System.out.println(ts);
		     
		     System.out.println("descending order");
		     Iterator<Integer> ionj =ts.descendingIterator();
		       while(ionj.hasNext()) {
		    	   System.out.print(ionj.next()+" ");
		       }
		     System.out.println("");
		     
		
	}
}
