package com.training.map;

import java.util.Comparator;

public class MyStudentComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
	        
		int id1=o1.getStudId();
		int id2=o2.getStudId();
		if(id1<id2) {
			return -1;
		}else if(id1>id2){
			return 1;
		}else {
			return 0;
		}
		
	}

}
