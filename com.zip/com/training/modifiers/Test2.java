package com.training.modifiers;

import com.training.keyword.ExamOnAccessModfiers;

public class Test2 {
     public static void main(String[] args) {
	
	 ExamOnAccessModfiers eoaf = new ExamOnAccessModfiers(); 
		//System.out.println(eoaf.a); //default
		//System.out.println(eoaf.b); //private
		//System.out.println(eoaf.name);//protected
		System.out.println(eoaf.pi);

			//eoaf.methodOne(); //default
			//eoaf.methodTwo(); //private
			//eoaf.methodThree(); //protected
			eoaf.methodFour();
}
}
