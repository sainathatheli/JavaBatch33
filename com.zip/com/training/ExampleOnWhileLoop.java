package com.training;

public class ExampleOnWhileLoop {
  
	public static void main(String[] args) {
	
	   int i=1; //initialization
	   while(i<=10) {
		   System.out.println(i);
		   i+=1; //i=i+1;
	   }
	   
	   System.out.println("------------------------------------------");
	   
	  int n=2,j=1;
	  while(j<=10) {
		  System.out.println(n+"X"+j+"="+(n*j));
		  j+=1;
	  }
			
	  
}
}
