package com.training.java8features;

public class Ex1 implements MyInterface8{

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in method one of ex1 class");
	}

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are in method Two of ex1 class");
	}

	@Override
	public void methodThree() {
		// TODO Auto-generated method stub
		System.out.println("we are in method Three of ex1 class");
	}

	public static void main(String[] args) {
		
		MyInterface8 eonj8 = new Ex1();
		eonj8.methodOne();
		eonj8.methodTwo();
		eonj8.methodThree();
		eonj8.display();
		MyInterface8.sayHell();
		
	}
	
	
}
