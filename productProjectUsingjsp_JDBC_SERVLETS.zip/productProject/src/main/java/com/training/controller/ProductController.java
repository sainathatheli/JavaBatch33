package com.training.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.dao.ProductDao;
import com.training.dao.ProductDaoImpl;
import com.training.dto.Product;

@WebServlet("/product")
public class ProductController extends HttpServlet{
	
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		//product details from the from product.jsp
		
		String pid =req.getParameter("pid");
		String pname =req.getParameter("pname");
		String price =req.getParameter("price");
		
		int id = Integer.parseInt(pid);
		float pc = Float.parseFloat(price);
		
		Product p = new Product(); //creating dto object storing the form data
		p.setPid(id);
		p.setPname(pname);
		p.setPrice(pc);
		
		//creating the object for productDaoImpl class and call insertProduct(Product p) method
		ProductDao productDao=new ProductDaoImpl();
		int count=productDao.insertProduct(p);
		if(count > 0){
			out.println("Record inserted successfully");
			out.println("<br>");
			out.println("<a href='product.jsp'>Add One More Product Details</a>");
			out.println("<br>");
			out.println("<br>");
			out.println("<a href='list'>List Product Details</a>");
		}else {
			out.println("Record not inserted");
		}
		
		out.close();
	}

}
