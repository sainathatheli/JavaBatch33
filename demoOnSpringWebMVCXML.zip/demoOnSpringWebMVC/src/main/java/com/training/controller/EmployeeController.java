package com.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {

	@RequestMapping("/show")
	public String showMsg() {
		return ("insert");//returning view
	}

	@RequestMapping("/show2")
	public ModelAndView showPage() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("Home");//view layer (Home.jsp)
		return mav;
	}
}


