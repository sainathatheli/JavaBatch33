package com.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.training.dto.Product;
import com.training.utils.DBUtils;

public class ProductDaoImpl implements ProductDao{

	@Override
	public int insertProduct(Product p) {
    int count=0;
    Connection con = DBUtils.getDBConnection();
    String query="insert into product values(?,?,?)";
    
    try {
		PreparedStatement pstmt = con.prepareStatement(query);
		pstmt.setInt(1,p.getPid());
		pstmt.setString(2,p.getPname());
		pstmt.setFloat(3,p.getPrice());
		
		count=pstmt.executeUpdate();
		
		DBUtils.closeDBConnection();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
		return count;
		
	}

	@Override
	public List<Product> listProductDetails() {
		List<Product> plist = new ArrayList<Product>();
		Connection con = DBUtils.getDBConnection();
	    String query="select * from product";
	    
	    try {
			PreparedStatement pstmt = con.prepareStatement(query);
			
			ResultSet rs =pstmt.executeQuery();
			while(rs.next()) {
				Product p = new Product();
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setPrice(rs.getFloat(3));
				plist.add(p);
				
			}
			
			DBUtils.closeDBConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return plist;
	}

}
