package com.training.java8features;

public class Ex2 implements MyInterface8{

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in method one of ex2 class");
	}

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are in method Two of ex2 class");
	}

	@Override
	public void methodThree() {
		// TODO Auto-generated method stub
		System.out.println("we are in method Three of ex2 class");
	}
	
	@Override //default method override in ex2
	public void display() {
		System.out.println("default display method override in any implementation class");
	}
	
	/*  static method from the interface cannot be override in implementation classes.
	 * @Override public void sayHell() { }
	 */

	public static void main(String[] args) {
		
		MyInterface8 eonj8 = new Ex2();
		eonj8.methodOne();
		eonj8.methodTwo();
		eonj8.methodThree();
		eonj8.display();
		MyInterface8.sayHell();
		
	}
	
	
}
