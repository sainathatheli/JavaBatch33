package com.training;

public class ExampleOnMethods {

	void methodOne() {
		System.out.println("we are in methdOne with zero arguments");
	}
	
	public int getAddition(int x,int y) {//x,y formal parameters
		//int res = x+y;
		return x+y;        //instance with two arguments
	}
	
	public static void methodTwo() {
		System.out.println("we are in methodTwo zero argument static method");
	}
	
	
	protected static String sayHello(String str) {
		return str;
	}
	
	public final void methodThree() {//we cannot override in child class
		System.out.println("we are in methodThree zero argument final method");
	}

	 public static void main(String[] args) {
		
		 ExampleOnMethods eom = new ExampleOnMethods();
		 eom.methodOne();
		 int sum =eom.getAddition(10,30); //10,20 actual parameters
		 System.out.println("sum values is : "+sum);
		 
		 ExampleOnMethods.methodTwo();//calling static methods
		 String s=ExampleOnMethods.sayHello("welcome to methods");
		 System.out.println(s);
		 
		 eom.methodThree();
		 
	}
	
}
