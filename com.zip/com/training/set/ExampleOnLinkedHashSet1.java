package com.training.set;

import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.Set;

public class ExampleOnLinkedHashSet1 {
    ///heterogeneous elements
	public static void main(String[] args) {
		
		Set<Object> sobj = new LinkedHashSet<>();
		sobj.add(10);
		sobj.add(true);
		sobj.add("raju");
		sobj.add(10);
		sobj.add(20f);
		sobj.add('a');
		
		System.out.println("No of objects stored in Hashset is : "+sobj.size());
		System.out.println(sobj);
		
		sobj.remove("raju");
		
		System.out.println("After remove");
		System.out.println(sobj);
		
	    //search using contains method
		System.out.println("IS elemenet is exist: "+sobj.contains(10));
		
		System.out.println("Displaying the elements using enchanced for loop");
		for(Object o: sobj) {
			System.out.println(o);
		}
		
		System.out.println("Displaying the elements using iterator");
		Iterator iobj =sobj.iterator();//forward direction
		while(iobj.hasNext()) {
			System.out.println(iobj.next());
		}
		
		System.out.println("Displaying the elements using Java8 forEach");
		
		sobj.forEach(x->{System.out.println(x);});
	
	}
	
	
}
