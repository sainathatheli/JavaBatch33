package com.training;

public class Vehicle {
      
	 public void vehicleInfo() {
	 System.out.println("we are in vehicle class parent class");
	 }
	
}
