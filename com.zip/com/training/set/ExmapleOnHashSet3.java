package com.training.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.list.Employee;

public class ExmapleOnHashSet3 {
	///storing javabeab object into HashSet

	public static void main(String[] args) {

		Set<Product> hs = new HashSet<Product>(); 

		Product p1 = new Product(101,"mouse",400);
		Product p2 = new Product(102,"monitor",5000);
		Product p3 = new Product(103,"laptop",40000);
		Product p4 = new Product(102,"monitor",5000);
   
		System.out.println("p2: "+p2.hashCode());
		System.out.println("p4: "+p4.hashCode());
		System.out.println(p2==p4);
		System.out.println(p2.equals(p4));
		
		
		
		Product p5 = new Product();
		p5.setPid(104);
		p5.setPname("ram");
		p5.setPrice(8000);

		hs.add(p1);
		hs.add(p2);
		hs.add(p3);
		hs.add(p4);
		hs.add(p5);

		System.out.println(hs);

		System.out.println("Display the product details using enhanced for loop");
		System.out.println("---Product Details are ----------");
		for(Product p : hs) {
			System.out.println(p.getPid()+" "+p.getPname()+" "+p.getPrice());
		}
      System.out.println(" ");
		System.out.println("Display the product details using iterator");
		System.out.println("---Product Details are ----------");

		Iterator<Product> iobj = hs.iterator();
		while(iobj.hasNext()) {
			Product p =iobj.next();
			System.out.println(p.getPid()+" "+p.getPname()+" "+p.getPrice());
		}
		








	}
}
