package com.training;

public class B extends A{
  
	public void methodTwo() {
		System.out.println("we are in methodTwo of B class");
	}
}
