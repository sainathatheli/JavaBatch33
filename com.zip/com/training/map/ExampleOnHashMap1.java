package com.training.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ExampleOnHashMap1 {
	public static void main(String[] args) {

		Map<Integer,String> hm = new HashMap<Integer,String>(); //<k,V> generics
		//adding the elements into hashmap using put()
		
		hm.put(40,"martin");
		hm.put(300,"Ramesh");
		hm.put(201,"Smith");
		hm.put(401,"scott");
		hm.put(100,"Allen");
		hm.put(40,"sagar"); //it will not throws any error,it will replace or override
		
		System.out.println(hm);
		
		//get the data based on key  using get(Key)
		
		String key=hm.get(201);
		System.out.println("value for the key 201 is : "+key);
		
		//search based on key
		System.out.println("Search key is exist or not ? : "+hm.containsKey(50));
		
		//remove a object based on key
		System.out.println("Before remove : "+hm);
         hm.remove(100);
         System.out.println("after remove : "+hm);
         
         //get Only the keys
           Set<Integer> sk =hm.keySet();
           System.out.println("Keys are :");
           for(Integer si : sk) {
        	   System.out.println(si);
           }
		 System.out.println("");
        //get Only values
		 System.out.println("Values are :");
		   Collection<String> cobj =hm.values();
		   for(String s:cobj) {
			   System.out.println(s);
		   }
		 
		   //getting key,values pairs using entrySet
		   System.out.println("Key and values are using enhance for loop :");
		   for(Map.Entry<Integer,String> mh : hm.entrySet()) {
			   System.out.println(mh.getKey()+" "+mh.getValue());
		   }
		   
		   //getting key,values pairs using entrySet
		   System.out.println("Key and values are using java8 foreach() :");
		   hm.forEach((k,v) ->{System.out.println(k+" "+v);});
		
	}
}
