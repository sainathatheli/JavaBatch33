package com.training;

public interface H1 {
	void methodOne();
}
