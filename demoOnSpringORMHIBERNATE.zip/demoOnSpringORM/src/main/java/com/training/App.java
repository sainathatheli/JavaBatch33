package com.training;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.config.AppConfig;
import com.training.entity.User;
import com.training.service.IUserService;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args )
	{

		//ApplicationContext ac = 
				//new ClassPathXmlApplicationContext("applicationContext.xml");
		
		ApplicationContext ac = 
				new AnnotationConfigApplicationContext(AppConfig.class);
		
		IUserService u = 
				(IUserService)ac.getBean("serviceUserImpl");

		/*
		 * User user = new User(); user.setUserId(3);
		 * user.setUserName("RAVI SAM Sharma"); user.setUserCode("Uss5"); u.save(user);
		 * System.out.println("Saved data successful");
		 */
		 
		/*
		 * User user = new User(); user.setUserId(3); user.setUserName("VickyRajkumar");
		 * user.setUserCode("psdf"); u.update(user);
		 * System.out.println("update succesfull");
		 */
		 
		
    			//Delete operation
				/*
				 * User user = new User(); user.setUserId(3); u.delete(3);
				 * System.out.println(3+" user deleted");
				 */
		 
		/*
		 * //retrive data in list<User> List<User>list = u.getAllUsers(); for(User
		 * user:list) System.out.println(user);
		 */
		//retrive only one user data` /
		User user = u.getUserById(101);
    			System.out.println(user.getUserCode()+" "+user.getUserId()+" "+user.getUserName());
		//HibernateTransactionManagerhh;
		// hh.setSessionFactory(sessionFactory);
	}
}
