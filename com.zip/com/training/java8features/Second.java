package com.training.java8features;

@FunctionalInterface
public interface Second { //SAM
     public int getSum(int x, int y);
}
