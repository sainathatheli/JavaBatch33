package com.training;

import java.util.Scanner;

public class ExampleOnSwitchCase {

	public static void main(String[] args) {
		
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter the first number : ");
		int a=sobj.nextInt();
		
		System.out.println("Enter the second number : ");
		int b=sobj.nextInt();
		
		System.out.println("Enter the operation  you want to do ");
		String oper =sobj.next();
		
		switch(oper) {
		case "+":System.out.println("sum of two numbers is : "+(a+b));
		         break;
		case "*": System.out.println("Multiplication of two numbers is : "+(a*b));
		          break;
		case "%" :System.out.println("Modulus of two numbers is : "+(a%b));
		          break;
		          
		default:System.out.println("Invalid Operation");
		
		}
		
		
		
		
		
		
	}
	
}
