package com.training;

public interface MyApp {
	static final int a=10;
	String s="world";
	public abstract void methodOne();
	int getSum(int x,int y);
}
