package com.training;

public class ExampleOnVariables {
	
	int empNo=1001;
	String empName="smith";
	float empSal=3000;    //instance variables
	
	static String compayName="XYZ"; //static variable
		
	public void methodOne() {  //instance method
		int a=10; //local variable
	   System.out.println("Local variable values is : "+a);
	   	
	}
	public static void main(String[] args) {
		//creating a object for a class using new operator
		//syntax :- ClassName referencevariable=new ClassName();
		
		ExampleOnVariables  eov =new ExampleOnVariables();
		System.out.println("Empno is :"+eov.empNo);
		System.out.println("Ename is : "+eov.empName);
		System.out.println("Employee  Salary is : "+eov.empSal);
		
		
     //accessing the static variable with the help of ClassName.variableName
		System.out.println("Company Name is : "+ExampleOnVariables.compayName);
		//System.out.println("Company Name is : "+eov.compayName);
		
	    eov.methodOne();
		
	}
	
	
	
}
