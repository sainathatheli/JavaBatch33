package com.training.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.bean.Employee;
import com.training.bean.Product;

@Configuration
public class JavaConfig {
	
	@Bean(name = "empJavaConfig")
	public Employee getEmployeeObject() {
		
		//setter injection
		Employee e= new Employee();
		e.setEmpId(1001);
		e.setEmpName("martin");
		e.setEmpSal(5000);
		
		return e;
		
	}
	
	@Bean(name = "prodObj")
	public Product getProductObj() {
		return new Product(1005,"monitor",5000);
		
	}
	
}
