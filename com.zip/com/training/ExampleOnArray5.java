package com.training;

public class ExampleOnArray5{

    public static void main(String args[]){

      int a[][]={{1,2,3},{10,30,50}};  //        1    2    3
                                          //     10  30  50     2 rows and  3 cols
                                           //no of elements in array is  rows*cols
    for(int i=0;i<2;i++){ //rows
   
        for(int j=0;j<3;j++){ //colums

      System.out.print(a[i][j]+" ");
    }
      System.out.println("");
   }
}
}