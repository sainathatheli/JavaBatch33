package com.training;

public interface I1 {
	 public abstract String getMessage();
     void display();
}
