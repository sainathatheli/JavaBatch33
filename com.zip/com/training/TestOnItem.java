package com.training;

public class TestOnItem {

	public static void main(String[] args) {
		
		Item item = new Item();
		
		//initialize the private instance variables using setter methods
		item.setItemId(1001);
		item.setItemName("Dryfruits");
		item.setPrice(4000);
		
		//get the data from the private instamce variables using getter methods
		
		System.out.println("Item detailas are ");
		System.out.println(item.getItemId()+" "+item.getItemName()+" "+item.getPrice());
		
		
		
	}
}
