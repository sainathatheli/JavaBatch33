package com.training.java8features;

@FunctionalInterface
public interface Messageable {
	  Message getMessage(String msg);  
}
