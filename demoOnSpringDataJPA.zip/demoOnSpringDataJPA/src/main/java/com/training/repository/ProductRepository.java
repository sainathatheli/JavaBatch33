package com.training.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.bean.Product;

@Repository
public interface ProductRepository  extends JpaRepository<Product,Integer>{
	
	//select * from prodtab where prod_code=prodCode;
	
	  Optional<Product> findByProdCode(String prodCode);//custom find method by the
	  //programmer //select * from prodtab where prod_code like prodCode
	  List<Product> findByProdCodeLike (String pc);
	 

	/*
	 * @Query("select p from Product p where p.prodCode=:a or p.prodName:b")
	 * List<Product> getAllProducts(String a, String b);
	 */
	
}
