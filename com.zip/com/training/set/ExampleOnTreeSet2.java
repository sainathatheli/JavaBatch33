package com.training.set;

import java.util.Set;
import java.util.TreeSet;

public class ExampleOnTreeSet2 {
	//in treeset add the collection of student object

	public static void main(String[] args) {
		
		Set<Student> ts = new TreeSet<Student>(
				(s1,s2)->s1.getStudId()<s2.getStudId()?-1:s1.getStudId()>s2.getStudId()?1:0);
		Student s1 = new Student(301,"martin","boston");
		Student s2 = new Student(290,"john","Newjersey");
		Student s3 = new Student(302,"rahul","India");
		Student s4 = new Student(291,"allen","Aust");
		Student s5 = new Student(290,"rahul","India");
		
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		ts.add(s5);
		
		
		System.out.println(ts);
		System.out.println("Displaying the Student object from treeset using foreach loop");
		for(Student s : ts) {
			System.out.println(s.getStudId()+" "+s.getStudName()+" "+s.getAddress());
		}
		
		
	}

}
