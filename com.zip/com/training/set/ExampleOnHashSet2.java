package com.training.set;

import java.util.HashSet;
import java.util.Set;

public class ExampleOnHashSet2 {
	
	//storing Homogeneous elements
	public static void main(String[] args) {
		
       Set<String> sobj = new HashSet<String>(); //<T> generic type
		sobj.add("raju");
		sobj.add("smith");
		sobj.add("raju");
		sobj.add(new String("martin"));
		sobj.add("scott");
		
		System.out.println(sobj);
		
		 Set<Integer> sobj1 = new HashSet<Integer>(); //<T> generic type
		 			sobj1.add(20);
		            sobj1.add(10);
		            sobj1.add(30);
		            sobj1.add(40);
		            sobj1.add(10);
			
			System.out.println(sobj1);
		
	}
	
	

}
