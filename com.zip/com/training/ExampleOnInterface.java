package com.training;

public class ExampleOnInterface extends MyFirstImpl{

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodTwo of newly created class here we implemented");
	}

	
	public static void main(String[] args) {
		
		//1st way to create the object
		//Interface ReferenceVariable = new ImplementationClassObject();
		MyFirst myFirst = new ExampleOnInterface();
		
		String st =myFirst.sayHello();
		System.out.println(st);
		myFirst.methodOne();
		myFirst.methodTwo();
		
		System.out.println("2nd way of creating a object");
		ExampleOnInterface eof = new ExampleOnInterface();
		eof.methodOne();
		eof.methodTwo();
		System.out.println(eof.sayHello());
		
		System.out.println("variable: "+MyFirst.a);
		
		
	}
	
}
