package com.training.java8features;
@FunctionalInterface
public interface MReference2 {
    public String sayHello();
}
