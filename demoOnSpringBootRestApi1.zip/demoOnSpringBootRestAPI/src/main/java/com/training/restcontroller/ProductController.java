package com.training.restcontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Product;

@RestController
@RequestMapping("/prod")
public class ProductController {


	@GetMapping("/m1") //http://localhost:2019/myapp/prod/m1 -->endpoint url
	//http://localhost:2019/myapp/prod/m1?msg=ramu
	public String methodOne(@RequestParam("msg") String msg) {
		return msg+" welcome to spring boot restapi working with @request param";
	}


	@GetMapping("/m2") //http://localhost:2019/myapp/prod/m2 -->endpoint url
	//http://localhost:2019/myapp/prod/m2?empno=1001&ename=smith&sal=3000
	public String getEmpDetails(@RequestParam("empno") String empno,@RequestParam("ename") String ename,@RequestParam("sal") String sal) {
		return empno+" "+ename+" "+sal;
	}

	@GetMapping("/m3/{pid}") //http://localhost:2019/myapp/prod/m3/p102 --endpoint url /{} -pathvariable
	public String getProduct(@PathVariable String pid) {
      return "ProductID is : "+pid;
	}
	
	@GetMapping("/m4/{pid}/{pname}/{price}") //http://localhost:2019/myapp/prod/m4/p102/mouse/300 --endpoint url /{} -pathvariable
	public String getProductDetails(@PathVariable String pid,@PathVariable String pname,@PathVariable String price) {
      return "ProductID Details are  : "+pid+" "+pname+" "+price;
	}
	
	
	//@RequestBody
	 //http://localhost:2019/myapp/prod/insert  --endPoint url
	/*
	 * { "pid":1001, "pname:"smith"," "price":3000   //note in postman we need raw option->json
	 * 
	 * }
	 */
	@PostMapping("/insert")
	public Product getProductDetailsByRequestBody(@RequestBody Product p) {
		System.out.println("Injection into product using Request Body");
		return p;
	}	  
	
	
	
	
	
	
	
	
	


}
