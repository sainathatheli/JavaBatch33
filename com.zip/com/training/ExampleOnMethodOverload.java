package com.training;

public class ExampleOnMethodOverload{

	public  int getSum(int x,int y){
		int z=x+y;
		return z;
	}

	public int getSum(int x,int y,int z)
	{
		return x+y+z;
	}

	public void  methodOne(int x,float y){

		System.out.println(x+" "+y);

	}

	public void methodOne(float x,int y){

		System.out.println(x+" "+y);   
	}

	 public static void main(String[] args) {
		
		 ExampleOnMethodOverload eoml = new ExampleOnMethodOverload();
		 
		 int res=eoml.getSum(10,40);//getSum(int,int)
		 System.out.println("sum of two numbers is : "+res);
		 
		 eoml.methodOne(20,10f); //methodOne(int,float)
		 eoml.methodOne(10f,30); //methodOne(float,int)
	}
	
	
}