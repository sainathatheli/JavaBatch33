package com.training.operations;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.entity.Employee;

public class InsertRecordUsingHibernateORM {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		
		SessionFactory sessFactory = cfg.buildSessionFactory();
		Session  session=  sessFactory.openSession();
		
		Transaction tx=  session.beginTransaction();
		
		Employee e = new Employee();
		e.setEmpId(1002);
		e.setEmpName("martin");
		e.setEmpSal(5000);
		
	     session.save(e); //internally it will  employee object converted into insert query
		
		 tx.commit();
		 
		 
		
		
	}
	
}
