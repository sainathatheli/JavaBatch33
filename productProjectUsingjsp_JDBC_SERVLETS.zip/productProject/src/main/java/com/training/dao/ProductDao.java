package com.training.dao;

import java.util.List;

import com.training.dto.Product;

public interface ProductDao {
	
	public int insertProduct(Product p);
	public List<Product> listProductDetails();

}
