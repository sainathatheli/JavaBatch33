package com.training;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.training.bean.Student;
import com.training.bean.StudentRowMapper;
import com.training.config.AppConfig;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args )
	{

		/*
		 * ApplicationContext context = new
		 * ClassPathXmlApplicationContext("applicationContext.xml");
		 */

		//get the JDBC template Object
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		JdbcTemplate jt = (JdbcTemplate) context.getBean("jtObj");

		/*
		 * //Insert JDBC code String sql = "insert into student1 values(?,?,?,?)"; int
		 * count = jt.update(sql, 1003,"allen","spring",5000);
		 * 
		 * System.out.println("Student saved successfully :: "+count);
		 */
		 

	     //delete jdbc code
		/*
		 * String sql="delete from student1 where stdid=?"; int
		 * count=jt.update(sql,1005);
		 * System.out.println("student record is deleted "+count);
		 */


          //update SPring jdbc code
			/*
			 * String sql="update student1 set stdname=? where stdid=?"; int
			 * count=jt.update(sql,"martin",1001);
			 * System.out.println("student record is updated "+count);
			 */

		String sql = "select * from student1 where stdid=?";
		StudentRowMapper srm = new StudentRowMapper();
		Student s = jt.queryForObject(sql, srm, 1001);
		System.out.println(s);
		
      
		String sql1 = "select * from student1";
		StudentRowMapper srm1 = new StudentRowMapper();
		List<Student> lst= jt.query(sql1,srm1);
		
		System.out.println("All the Records from the student1 table");
		lst.forEach(System.out::println);
		
		
		
	}
}
