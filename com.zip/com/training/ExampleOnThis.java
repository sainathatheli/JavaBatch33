package com.training;

public class ExampleOnThis {

	int a=10;
	String s="hello";
	int empNo;
	String empName;
	float empSal;
	
	public ExampleOnThis() {
		 this(1001,"smith",3000);//calling parameter using this
	   System.out.println("we are in default constructor");
	  
	}
	
	public ExampleOnThis(int empNo,String empName,float empSal) {
		   System.out.println("we are in Parameter constructor");
		   this.empNo=empNo;
		   this.empName=empName;
		   this.empSal=empSal;
		   System.out.println(empNo+" "+empName+" "+empSal);
		}
	public void methodOne() {
		int a=30;
		System.out.println("we are in instance method One");
		System.out.println("a local variable is:  "+a);
		System.out.println("a instance variable is : "+this.a);
		this.methodTwo();
	}
	
	public void methodTwo() {
		System.out.println("we are in instance method Two");
	}
	
	public static void main(String[] args) {
		
		ExampleOnThis eot = new ExampleOnThis();
		eot.methodOne();
		
		
	}
	
}
