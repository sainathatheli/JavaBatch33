package com.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("emp")
public class EmployeeController {
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "Home";
	}

}
