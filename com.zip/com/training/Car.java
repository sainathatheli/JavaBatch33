package com.training;

public class Car extends Vehicle{ //single inheritance

	 public void carInfo() {
		 System.out.println("we are in car class is a child class");
	 }
	 public static void main(String[] args) {
		
		 Car cobj = new Car();
		 //calling the methods of child class
		 cobj.carInfo();
		 
		 //calling the methods of parent class
		 cobj.vehicleInfo();
	}
} 
	 

