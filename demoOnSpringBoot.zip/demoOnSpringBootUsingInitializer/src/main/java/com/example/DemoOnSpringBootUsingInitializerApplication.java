package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Profile;

import com.example.bean.Employee;
import com.example.bean.GeneralData;

@SpringBootApplication
public class DemoOnSpringBootUsingInitializerApplication implements CommandLineRunner {

	
	/*
	 * @Autowired private Employee e;
	 */
	  
	 	
	
	  @Autowired()
	  private GeneralData gd;
	 
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootUsingInitializerApplication.class, args);
		// System.out.println("welcome to springboot using Spring Initializer");
	}

	@Override
	public void run(String... args) throws Exception {
		/*
		 * // TODO Auto-generated method stub
		 * System.out.println("Employee Details are :");
		 * 
		 * e.setEmpId(1001); e.setEmpName("Martin"); e.setEmpSal(300);
		 * 
		 * 
		 * System.out.println(e);
		 */

		
		
		  System.out.println("From General Data class");
		  System.out.println(gd.getName());
		 
		
		//System.out.println(e);
	}

}
