package com.training.list;

import java.util.ArrayList;
import java.util.List;

public class ExampleOnArrayList2 {
   public static void main(String[] args) {
	//storing specific type of data using generic
	   
	 List<String> al = new ArrayList<String>(); //<T> Generice Type
	 
	 al.add("smith");
	 al.add("Ravi");
	 al.add("martin");
	 al.add(new String("Hello"));
	 al.add("john");
	 al.add("Ravi");
	 al.add("10");
	 //al.add(10);
	 
	 System.out.println(al);
}
}
