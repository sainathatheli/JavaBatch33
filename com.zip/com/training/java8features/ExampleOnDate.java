package com.training.java8features;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class ExampleOnDate {
	public static void main(String[] args) { 
		
		LocalDate date = LocalDate.now(); 
		System.out.println(date); 
		
		LocalTime time=LocalTime.now(); 
		System.out.println(time); 
		
		
		int dd = date.getDayOfMonth(); 
		 int mm = date.getMonthValue(); 
		 int yy = date.getYear(); 
		 System.out.println(dd+"..."+mm+"..."+yy); 
		 
		 System.out.println("From the current time you extract mintues,seconds ,hours..");
		 int h = time.getHour(); 
		 int m = time.getMinute(); 
		int s = time.getSecond(); 
		int n = time.getNano();
		System.out.println(h+"..."+m+"..."+s+"..."+n); 
		
		LocalDateTime dt1=LocalDateTime.of(1995,04,28,12,45);
		System.out.println(dt1);
		System.out.println("After six months:"+dt1.plusMonths(6));
		System.out.println("before six months:"+dt1.minusMonths(6));
		 
	} 
}