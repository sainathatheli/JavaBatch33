package com.training;

public class ExampleOnArray2{

	  public static void main(String args[]){
	 
	  int a[] = new int[5];  //declared the array with size using new operator 
	  //initilaze the array 
	  a[0]=10;
	  a[1]=40;
	  a[2]=50;
	  a[3]=60;
	  a[4]=30;
	  //a[5]=23;

	  System.out.println("size of any arrray "+a.length);
	  //to display the elements using for loop

	   for(int i=0;i<a.length;i++){
	   System.out.print(a[i]+" ");
	   }

	  //display the elements using for-each loop
	   for(int b : a){

	   System.out.println(b);

	  }
	  }
}