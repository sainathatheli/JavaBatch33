package com.training;

public class ExampleOnTypeCasting {

	public static void main(String[] args) {
		
		int a=10;
		System.out.println("a value is : "+a);
		
		double d =a;  //widening or implicitly casting
		System.out.println("After type cast from int to double :"+d);
		
		double d1=20 ;
		System.out.println("d1 value is : "+d1);
		
		//typecasting double to int
		int i1 =(int) d1;  //explicit casting or narrowing casting
		System.out.println("After explicit casting from double to int : "+i1);
		
		float x =(float) d1; //converting double to float

	    System.out.println("After converting to float: "+x);

	    long aa = 30;

	    float y= aa; //converting long to float 

	    System.out.println("After converting to long to float: "+y);
	    
	    int i2=98;
	    //converting int to char datatype
	    
	    char ch =(char)i2;
	    System.out.println("After typecasting int to char : "+ch);
	    
	    
	
	    
	    
	    
	    
	    
	    
		
		
		
		
		
		
		
		
		
		
			
		
	}
	
	
}
