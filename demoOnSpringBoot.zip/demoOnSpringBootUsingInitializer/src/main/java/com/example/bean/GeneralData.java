package com.example.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;


@Profile("qa")
@Component("gdata")
public class GeneralData {
	
	@Value("${my.name.from}")
	private String name;

	public GeneralData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "GeneralData [name=" + name + "]";
	}
	
	
	
}
