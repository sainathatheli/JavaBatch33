package com.training.java8features;

public class TestOnMethodReference2 {
	
	public String display() {
		return "welcome to method Reference using instance";
	}
	
	public static void main(String[] args) {
		TestOnMethodReference2 tm2 = new TestOnMethodReference2();
		
		//MReference2 mr2 =()->"welcome to methodreference";
		
		MReference2 mr2 =tm2::display;
		System.out.println(mr2.sayHello());


	}
}
