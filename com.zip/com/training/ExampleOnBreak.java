package com.training;

public class ExampleOnBreak {

	public static void main(String[] args) {
		
		   int i=1; //initialization
		   while(i<=10) {
			   if(i>=6) {
				   break;
			   }
			   System.out.println(i);
			   i+=1; //i=i+1;
		   }
		   
	}
	
	
	
	
	
	
}
