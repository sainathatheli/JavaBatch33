package com.training.java8features;

public class TestOnlamda {

	public static void main(String[] args) {
		
		First fobj=()->{System.out.println("welcome to lamda expression");};
		
		fobj.display();
		
		Second sobj =(a,b) ->a+b; //lambda expression
	
		int res=sobj.getSum(10,30);
		System.out.println("SUm of two number using lambda expression is : "+res);
		
	}
	
}
