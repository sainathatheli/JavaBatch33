package com.training.keyword;

//public class Second extends First {final class cannot be inherited
public class Second{
	public void methodTwo() {
		System.out.println("we are in methodTwo");
	}
	
	/*
	 * @Override public void methodOne() {
	 * System.out.println("we are in chidl class methodOne"); }
	 */
   public static void main(String[] args) {
	  First fobj = new First();
	  fobj.methodOne();
	  System.out.println("sum of two numbers : "+fobj.getSum(10,50));
	  
	  Second second = new Second();
	  second.methodTwo();
	   
}
	
	
}
