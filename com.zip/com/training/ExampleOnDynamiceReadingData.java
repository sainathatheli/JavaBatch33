package com.training;

import java.util.Scanner;

public class ExampleOnDynamiceReadingData {
	
	public static void main(String[] args) {
		
	   Scanner s = new Scanner(System.in);	
	   
	   System.out.println("Enter the Empno");
	   int empNo =s.nextInt();
	   
	   System.out.println("Enter the EmpName");
	   s.nextLine();
	   String empName =s.nextLine();
	   
		
      System.out.println("Enter the EmpSal"); 
      float empSal =s.nextFloat();
		 
	   
	   System.out.println("Employee Details are : ");
	   System.out.println("EMpno : "+empNo);
	   System.out.println("EmpName : "+empName);
	   System.out.println("EmpSal  : "+empSal);
		
		
		
	}
	
}
