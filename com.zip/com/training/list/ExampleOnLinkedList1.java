package com.training.list;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.List;

public class ExampleOnLinkedList1 {

	public static void main(String[] args) {
		System.out.println("working with linekd list");
		List al = new LinkedList(); //it will accept any type of Object(heterogeneous of elements)
		
		al.add(10);     //internally it will convert into wrapper class object ex: int ->Integer
		al.add(true);    //internally it will convert into wrapper class object ex: boolean ->Boolean
		al.add('a');
	    al.add("hello");
	    al.add(10f);
	    al.add("raju");
	    al.add(10); //duplicate object
	
	   
	    System.out.println(al); //insertion order is preserved
	    System.out.println("no of elements in linkedlist al is : "+al.size());
	    
		System.out.println("At index position 3 the object is : "+al.get(3));
		//search the object is exist or not
		System.out.println("is 10 exist : "+al.contains(10));
		//search the object is exist or not
				System.out.println("is 20 exist : "+al.contains(20));
		
		 System.out.println("before replace : "+al);
		 al.set(4,"hi");
		 System.out.println("after replace at position 4 index is : "+al);
		 
		 System.out.println("before remove: "+al);
		 al.remove(2); //removing by index position
		 System.out.println("after remove the elements are : "+al);
		 
		 //List sblist=al.subList(0, 4);  //subList(startInde,EndIndex-1)
		 //System.out.println("sub list from array list al is : "+sblist);
		 
		 //sblist.clear();//all elements will be removed its become empty
		 
		 //System.out.println("After remove all elements : "+sblist);
		 
		 //displaying the elements using enchance for loop:
		 System.out.println("elements are : ");
		 for(Object l :al) {
		   System.out.println(l);
	      }
		  //using iterator or cursors
		   System.out.println("Displaying the elements using iterator");
		     Iterator<Object> itobj =al.iterator();
		     while(itobj.hasNext()) {
		    	 System.out.println(itobj.next());
		     }
		  System.out.println("Using java8 Foreach()");
		  al.forEach(x -> {System.out.println(x);});
		  
		  
		     
		 
}
}