package com.training.java8features;

public class ExampleOnConstructorReference {
	
   public static void main(String[] args) {
	
	  /* Messageable  mr3 = (x) -> new Message(x);
	   
	   System.out.println(mr3.getMessage("\"we are working with Constructor Referece\""));
}*/   
	   //Constructor Reference to functional interface Messageable
	   
	   Messageable mr3=Message::new;
	   Message m1=mr3.getMessage("welcome to constrcutor reference " );
	   System.out.println(m1);
	   
	     
   }
}
