package com.training;

public class Test3 extends ExampleOnSuper{

	int a=30;

	public Test3(){
		super();//it will call the parent class(ExampleOnSuper) default constructor 	
		System.out.println("we are in default constructor of Test class");

	}

	public void display(){

		super.display(); //calling display method from the parent class
		System.out.println("we are in display method of test class");
		System.out.println("Child class Varaible a is : "+this.a);
		System.out.println("Super class instance variable is : "+super.a);
        
	}

	public static void main(String[] args) {
       Test3 tob3 = new Test3();
       tob3.display();
       
	}




}