package com.training;

public interface I2 extends I1{
	public abstract String getMessage();
	void methodTwo();
}
