package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.bean.Product;
import com.training.config.AppConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	Product p=context.getBean("pobj",Product.class);
    	
    	System.out.println(p);
    	
    	
    	

   
    }
}
