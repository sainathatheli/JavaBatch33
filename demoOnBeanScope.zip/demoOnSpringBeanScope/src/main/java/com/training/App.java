package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.AppConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		/*  xml configuration
		 * ApplicationContext ac = new ClassPathXmlApplicationContext("spring.xml");
		 * 
		 * 
		 */
    		ApplicationContext ac = new AnnotationConfigApplicationContext(AppConfig.class);
    	
    	        Employee e1 = ac.getBean("emp" , Employee.class);
    			System.out.println(e1);
    			System.out.println(e1.hashCode());
    			Employee e2 = ac.getBean("emp" , Employee.class);
    			System.out.println(e2.hashCode());
    			Employee e3 = ac.getBean("emp" , Employee.class);
    			System.out.println(e3.hashCode());
    }
}
