package com.training.java8features;

@FunctionalInterface
public interface MReference {
   
	public void getSum(int x ,int y);
	
}
