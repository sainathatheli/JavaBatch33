package com.training.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.training.entity.User;

@Repository
public class UserDaoImpl implements IUserDao{

	@Autowired
	private HibernateTemplate ht;

	@Override
	public int save(User user) {
		return (Integer)ht.save(user);
	}
	@Override
	public void update(User user) {
		ht.update(user);
	}
	@Override
	public void delete(int userId) {
		User user = new User();
		user.setUserId(userId);
		ht.delete(user);
	}
	@Override
	public User getUserById(int userId) {
		User user = ht.get(User.class, userId);
		return user;
	}
	@Override
	public List<User>getAllUsers() {
		List<User> user = ht.loadAll(User.class);
		return user;
	}
}


