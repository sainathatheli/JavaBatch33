package com.training;

public class Student {

	int sid;
	String  sname;
	Address a; //has-a relation indirect relation
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int sid, String sname, Address a) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.a = a;
	}

	 public static void main(String[] args) {
		Address aobj = new Address("hyd","TG","In");
		Student sobj = new Student(1021,"martin", aobj);
		System.out.println("Student Details are :");
		System.out.println("sid : "+sobj.sid);
		System.out.println("sname: "+sobj.sname);	
		System.out.println("city : "+sobj.a.city);
		System.out.println("state: "+sobj.a.state);
		System.out.println("country : "+sobj.a.country);
	}



}
