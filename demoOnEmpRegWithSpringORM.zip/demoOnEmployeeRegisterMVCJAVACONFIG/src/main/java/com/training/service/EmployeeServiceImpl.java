package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.bean.EmployeeDTO;
import com.training.dao.IEmployeeDao;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeDao edao;

	@Override
	@Transactional
	public int saveEmployee(EmployeeDTO edto) {
		// TODO Auto-generated method stub
		return edao.saveEmployee(edto);
	}

}
