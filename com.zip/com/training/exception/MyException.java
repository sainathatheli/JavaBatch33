package com.training.exception;

public class MyException extends Exception{

	public MyException(String s) {
		super(s);
	}
	
}
