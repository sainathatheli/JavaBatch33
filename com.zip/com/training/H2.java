package com.training;

public interface H2 {
    void methodTwo();
}
