package com.training;

public class I2Impl implements I2{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("we are in display method");
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "AN interface can extend another interface";
	}

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodTwo");
	}

	public static void main(String[] args) {
		I2Impl  i2obj = new I2Impl();
		i2obj.methodTwo();
		i2obj.display();
		System.out.println(i2obj.getMessage());
		
		System.out.println("1st way of creating object");
		
		I2 i2 = new I2Impl();
		i2.methodTwo();
		i2.display();
		System.out.println(i2.getMessage());
		
	}
	
}
