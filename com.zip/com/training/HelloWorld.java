package com.training;

public class HelloWorld {

   public void sayHello() {
	   System.out.println("A class can extends and implements the interface also");
   }
}
