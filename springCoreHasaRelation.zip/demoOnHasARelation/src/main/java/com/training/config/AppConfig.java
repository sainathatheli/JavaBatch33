package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.bean.Address;
import com.training.bean.Employee;

@Configuration
public class AppConfig {

	@Bean
	public Address getAddressObject() {
		Address a= new Address();
		a.setCity("Hyd");
		a.setState("TG");
		return a;
	}
	
	@Bean("empObject")
	public Employee getEmployeeObject() {

		Employee e = new Employee();
		e.setEmpId(1001);
		e.setEmpName("Smith");
		e.setEmpSal(4000);
		e.setAddr(getAddressObject());
		
		return e;
	}
	
	
	
	
	
	
}
