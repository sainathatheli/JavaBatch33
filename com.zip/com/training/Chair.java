package com.training;

public class Chair {

	  String color="black";
	  String material="plastic";
      int wheels = 4; //properties

	  public void movieable(){  //actions

	  System.out.println("Chair is moveable");

	 }
	
	 public void seatAdjustable() {
		 System.out.println("Chair height can be adjustable");
	 }
	  
	 public static void main(String[] args) {
		
		 Chair cobj = new Chair();
		 
		System.out.println(cobj.material);
		System.out.println(cobj.wheels);
		System.out.println(cobj.color);
		cobj.movieable();
		cobj.seatAdjustable();
		 
		 
		 
	}
	 
	 
	
}
