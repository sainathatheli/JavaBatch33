package com.training;

public class ExampleOnSuper
{

int a=10;

public  ExampleOnSuper(){

  System.out.println("we are in default constructor of ExampleOnsuper");

}

 public void display(){

  System.out.println("we are in display method of ExampleOnsuper");

 } 

}