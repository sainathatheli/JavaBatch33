package com.training.curdoperation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.training.bean.Product;
import com.training.repository.ProductRepository;

@Component
public class ProductCurdOperations implements CommandLineRunner{
	
	@Autowired
	private ProductRepository repo;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		
		/*
		 * Product p = new Product(); p.setProdName("tv"); p.setProdCode("ptv");
		 * p.setPrice(50000);
		 * 
		 * repo.save(p); //insert into the table
		 */		 		  
		 
		
		//2.1 method.
		
		/*
		 * Optional<Product> p = repo.findById(152); if(p.isPresent()) {
		 * System.out.println(p.get()); } else { System.out.println("No Data found"); }
		 */
		 

		//2.2 Method.
		//repo.findAll().forEach((System.out::println));//it will all records;
		
		
		/*3. *****************Delete****************/
		//3.1 Delete by specific Id
		//repo.deleteById(2);
		
		//3.2 Delete all Rows one by one in (Sequence order) 
		//repo.deleteAll(); //Multiple Query fired No of record = no of Query

		//searching record based on prodcode by programmer custom method
		
		  Optional<Product> p = repo.findByProdCode("ptv"); if(p.isPresent()) {
		  System.out.println("Record is found based on prodCode");
		  System.out.println(p.get()); }
		  
		  else { System.out.println("No Data found"); }
		  
		  //displaying all record based on prodcode by programmer custom method
		  List<Product> p1= repo.findByProdCodeLike("ptv");
		  System.out.println("by using ProdCodeLike method");
		  p1.forEach(System.out::println);
		 
		
		//selection with help of @Query by writing custom select query with named parameter
		/*
		 * System.out.println("Displaying with @Query custom select"); List<Product> p2=
		 * repo.getAllProducts("ptv","tv"); p2.forEach(System.out::println);
		 */
	}

}
