package com.training;

public abstract class MyFirstImpl implements MyFirst {

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "welcome to interface";
	}

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodOne of MyFIrstImpl");
	}
	
	

}
