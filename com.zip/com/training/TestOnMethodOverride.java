package com.training;

public class TestOnMethodOverride extends ExampleOnMethodOverride {
	
	@Override
	public void methodOne() { //overridden method from parent to child
		System.out.println("we are in methodOne of child class");
	}
	
	public void methodThree() {
		System.out.println("we are in methodThree of child class");
	}
	
	public static void main(String[] args) {
		  //normal ways of creating object
		/*
		 * TestOnMethodOverride tomv= new TestOnMethodOverride();
		 * tomv.methodOne();//methodOne() //override method from parent to child
		 * tomv.methodThree(); tomv.methodTwo();
		 */
		//creating object as parent class reference variable holdings its child class object
		ExampleOnMethodOverride eomv = new TestOnMethodOverride();
		
		eomv.methodOne();
		//eomv.methodThree();
		
		
		
	}
}
