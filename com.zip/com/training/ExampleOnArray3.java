package com.training;

import java.util.Scanner;

public class ExampleOnArray3{

	 public static void main (String args[]){
	  
	    int c[] = new int[5];

	   //initialize the array using for loop using keyboard  
	   Scanner s= new Scanner(System.in);
	          
	   for(int i=0;i<c.length;i++){

	     System.out.println("enter the value for C array");
	    c[i]=s.nextInt();

	   }
	     //to display the values from array c

	        for(int i=0;i<c.length;i++){
		    System.out.println(c[i]);

		   }

	   //foreach-loop
		for(int i :c){
	  	 	System.out.print(i+" ");
	  	}
	  
	    }}
