package com.training;

public class ExampleTypePromotion {

	
	  public void methodOne(int a){ 
		  System.out.println("int value of a is "+a);
		  }
	 
	public void methodOne(float a){
		System.out.println("float value of a "+a);    
	}

	public void methodOne(double a){

		System.out.println("double value of a "+a);    
	}

	public static void main(String args[]){

		ExampleTypePromotion ept =new ExampleTypePromotion();

		ept.methodOne(10);  //methodOne(int)
		//ept.methodOne(10.5);

		ept.methodOne('a'); //methodOne(char)



	}
}
