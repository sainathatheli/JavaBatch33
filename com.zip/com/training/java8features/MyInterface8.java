package com.training.java8features;

public interface MyInterface8 {
	
	public abstract void methodOne();
	public void methodTwo();
	 void methodThree();
	 
	default void  display() {
		System.out.println("we are in default method");
	}
	
	static void sayHell() {
		System.out.println("we are in static method of java 8 interface cooncept");
	}
}
