package com.training.exception;

public class ExampleOnException4 {

	 public static void main(String[] args) throws InterruptedException {
		
		 System.out.println("statement -1");
		   
		 Thread.sleep(2000);
		 
		 System.out.println("statement -3");
		 
	}
	
	
}
