package com.training.bean;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StudentRowMapper implements RowMapper<Student>{

	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		Student s = new Student();
		s.setStdId(rs.getInt(1));
		s.setStdName(rs.getString(2));
		s.setCourse(rs.getString(3));
		s.setStdFee(rs.getFloat(4));
		return s;

	}

}
