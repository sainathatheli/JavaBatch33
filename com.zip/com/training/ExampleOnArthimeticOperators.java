package com.training;

import java.util.Scanner;

public class ExampleOnArthimeticOperators {
	
	public static void main(String[] args) {
		
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Enter the first number : ");
		int a=sobj.nextInt();
		
		System.out.println("Enter the second number : ");
		int b=sobj.nextInt();
		
		//int a=10; hard coding
		//int b=2;
		
		//int c=a+b;
		
		System.out.println("Sum of two numbers is : "+(a+b));
		System.out.println("Sub of two numbers is : "+(a-b));
		System.out.println("Multiplication of two numbers is : "+(a*b));
		System.out.println("Division of two numbers is : "+(a/b));
		System.out.println("Modulues of two numbers is : "+(a%b));
		
		//ternary operator
		int res=a>b?a:b;
		System.out.println("The result is : "+res);
		
		
		
		
		
		
	}
	
	

}
