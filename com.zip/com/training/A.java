package com.training;

public class A { //multi-level
 
	public void methodOne() {
		System.out.println("we are in methodOne of A class ");
	}
}
