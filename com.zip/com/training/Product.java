package com.training;

public class Product {

	int pid;
	String productName;
	float price;
	
	public Product() {
		System.out.println("we are in default constructor");
	}

	public Product(int pid, String productName, float price) {
		this.pid = pid;
		this.productName = productName;
		this.price = price;
	}
	
	
	
	
	
}
