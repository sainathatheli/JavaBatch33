package com.training;

public interface M1 {
  public abstract void methodOne();
}
