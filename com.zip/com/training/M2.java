package com.training;

public interface M2 {
   void methodTwo();
}
