package com.training;

public class Employee {

	 int empNo;
	 String empName;
	 float  empSal;
	 
	 public Employee(){  //default constructor
		 System.out.println("We are in default constructor");
	 }
	      ///parameterized constructors
	 public Employee(int empNo,String empName,float empSal) {
		this.empNo=empNo;
		this.empName=empName;
		this.empSal=empSal;
	 }
	 
	public static void main(String[] args) {
		Employee eobj = new Employee();
		//Employee eobj1 = new Employee();
		System.out.println("Default value for empNO : "+eobj.empNo);//0
		System.out.println("Default value for empName : "+eobj.empName);//null
		System.out.println("Default value for empSal : "+eobj.empSal);//0.0
		
		/*System.out.println("--second objet eobj1");
		System.out.println("Default value for empNO : "+eobj1.empNo);//0
		System.out.println("Default value for empName : "+eobj1.empName);//null
		System.out.println("Default value for empSal : "+eobj1.empSal);//0.0
		*/
		
		//creating object with parameter constructor
		System.out.println("--creating object with parameter constructor");
		Employee eobj2 = new Employee(1001,"smith",4000);
		System.out.println("Default value for empNO : "+eobj2.empNo);//1001
		System.out.println("Default value for empName : "+eobj2.empName);//smith
		System.out.println("Default value for empSal : "+eobj2.empSal);//4000
		
	}
	
}
