package com.training;

public class ExampleOnForLoop {

	public static void main(String[] args) {
		
		for(int i=1;i<=10;i++) {  
			System.out.println(i);		
		}
		
		System.out.println("*********************************");
		int n=5;
		for(int j=1;j<=10;j++) {  
			System.out.println(n+"X"+j+"="+(j*n));		
		}
		
		
		
	}
	
	
}
