package com.training.exception;

import java.util.Scanner;

public class ExampleOnException3 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		try {
		int arr[]= new int[3];
		
		for(int i =0 ; i<3;i++) {
			System.out.println("Enter the array elements :");
			arr[i]= sc.nextInt();
			
		}
		
		System.out.println("array elements are : ");
		for(int i =0 ; i<=3;i++) {
			System.out.println(arr[i]);
		}
		
		}catch(ArrayIndexOutOfBoundsException ae) {
                System.err.println("Array contain three elements i.e size is 3 but try to fetch 4th element you will get error");
		}catch(Exception e){
			e.printStackTrace();
		}
		


	}
}
