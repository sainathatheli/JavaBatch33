package com.training;

public class MyAppImpl implements MyApp{

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("We are in methodOne of MyAppImp1 class");
	}

	@Override
	public int getSum(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

	public static void main(String[] args) {

		//1st way of creating object
		//Interface referenceVariable = new ImplementationClassObject()
		MyApp myapp = new MyAppImpl();
		
		myapp.methodOne();
		int res=myapp.getSum(30,40);
		System.out.println(res);
		System.out.println("Accessing the variables");
		System.out.println(MyApp.a+" "+MyAppImpl.s);
		
		//2nd way
		System.out.println("2nd Way");
		 MyAppImpl myappimpl = new MyAppImpl();
		 myappimpl.methodOne();
		 System.out.println("sum is : "+myappimpl.getSum(40,10));
		 System.out.println("Variables : "+MyAppImpl.a+" "+MyApp.s);
		
		
	}

}
