package com.training.java8features;

public class TestOnMethodReference {
	//static method
	public static void addition(int a,int b) {
		 System.out.println("we are in static method");
		 System.out.println("sum value is : "+a+b);
	}
	
	public static void main(String[] args) {
			//static method reference
		//MReference mr1 = (x,y)->{System.out.println(x+y);};
		MReference mr1 = TestOnMethodReference::addition;
		mr1.getSum(20,40);
		
		
	}
	
	
}
