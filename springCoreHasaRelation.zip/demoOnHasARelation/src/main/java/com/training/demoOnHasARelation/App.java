package com.training.demoOnHasARelation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.bean.Employee;
import com.training.config.AppConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
     
    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	
       Employee eobj= context.getBean("empObject",Employee.class);
    	
    	System.out.println(eobj);//toString() 
    	
    	System.out.println("DEtails are ");
    	System.out.println(eobj.getEmpId()+" "+eobj.getEmpName()+" "+eobj.getEmpSal());
    	System.out.println(eobj.getAddr().getCity()+" "+eobj.getAddr().getState());
    	
    	
    	
    	
    }
}
