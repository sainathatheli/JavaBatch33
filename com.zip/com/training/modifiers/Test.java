package com.training.modifiers;

import com.training.keyword.ExamOnAccessModfiers;

public class Test extends ExamOnAccessModfiers{

	public static void main(String[] args) {
		
		Test eoaf = new Test(); 
		//System.out.println(eoaf.a);//default 
		//System.out.println(eoaf.b); //private
		System.out.println(eoaf.name);
		System.out.println(eoaf.pi);

			//eoaf.methodOne(); //default 
			//eoaf.methodTwo(); //private
			eoaf.methodThree(); 
			eoaf.methodFour();
		
	}
	
}
