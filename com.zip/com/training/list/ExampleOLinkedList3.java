package com.training.list;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.List;

public class ExampleOLinkedList3 {
    public static void main(String[] args) {
	
	 List<Employee> al = new LinkedList<Employee>(); 
	 
	 //using constructor
	 Employee e1 = new Employee(1001,"smith",4000);
	 Employee e2 = new Employee(1002,"Martin",5000);
	 Employee e3 = new Employee(1003,"John",3000);
	 
	 al.add(e1);
	 al.add(e2);
	 al.add(e3);
	 
	 //using 2nd way
	 Employee e4 = new Employee();
	 e4.setEmpId(1004);
	 e4.setEname("Adams");
	 e4.setEmpSal(5000);
	 
	 al.add(e4);
	 System.out.println(al);
	 
	 //using ennached for loop 
	 System.out.println("Using the enchanced for loop");
	 for(Employee e : al) {
		 System.out.println(e.getEmpId()+" "+e.getEname()+" "+e.getEmpSal());
		 
	 }
	 
	 //using the iterator or cursor
	 System.out.println("Using the Iterator");
	    Iterator<Employee> iobj =al.iterator();
	    while(iobj.hasNext()) {
           Employee e = iobj.next();
           System.out.println(e.getEmpId()+" "+e.getEname()+" "+e.getEmpSal());
	    }
	    
	    System.out.println("Using the java8 foreach()");
	    al.forEach(e ->{System.out.println(e.getEmpId()+" "+e.getEname()+" "+e.getEmpSal());});
	    
	 
  }
}
