package com.training.set;

import java.util.Comparator;

public class StudentComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		 /*int id1 = o1.getStudId();
		 int id2=  o2.getStudId();
		 //custom sorting order using Student sid instance variable
		 if(id1 < id2 ) {
			 return 1;
		 }else if(id1> id2) {
			 return -1;
		 }else {
			 return 0;
		 }
	}*/     String s1 = o1.getStudName();
			String s2 = o2.getStudName();
			
			return s2.compareTo(s1);
		
		
		
	}
}
