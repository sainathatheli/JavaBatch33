package com.training.exception;

import java.util.Scanner;

public class ExmapleOnException2
{

	public static void main(String args[]){

		Scanner s = new Scanner(System.in);

		try{
			System.out.println("Enter the value for n : ");
			int n =Integer.parseInt(s.nextLine()); //converting the string into Int
			if(10%n==0){

				System.out.println("10 is divisible by "+ n);
			}
		}catch (ArithmeticException|NumberFormatException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		/*catch(ArithmeticException ae){

			System.out.println(ae.getMessage());

		}catch(NumberFormatException ne){

			System.out.println(ne.getMessage());

		}catch(Exception e){

			e.printStackTrace();
		}*/
		System.out.println("statement 2");
	}

}
