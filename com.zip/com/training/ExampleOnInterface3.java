package com.training;

public class ExampleOnInterface3 extends HelloWorld implements H1,H2{

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		System.out.println("we are  in methodTwo");
	}

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		System.out.println("we are in methodOne");
	}
	
	public static void main(String[] args) {
		
		ExampleOnInterface3 eof3 = new ExampleOnInterface3();
		
		eof3.methodOne();
		eof3.methodTwo(); 
		System.out.println("Calling the parent class method");
		
		eof3.sayHello();
	}
	

}
