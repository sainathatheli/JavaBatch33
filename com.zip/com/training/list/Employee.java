package com.training.list;
//model or java bean class or encapsulated class or Pojo
public class Employee {
     
	private int empId;
	private String ename;
	private float  empSal;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String ename, float empSal) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.empSal = empSal;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	
	
	
	
	
	
	
	
	
}
