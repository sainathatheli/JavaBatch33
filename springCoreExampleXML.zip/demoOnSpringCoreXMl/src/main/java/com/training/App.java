package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.bean.Employee;
import com.training.bean.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //load or register your applicationContext.xml into bean/applicationcontext
    	//container
    	ApplicationContext context =  new ClassPathXmlApplicationContext("applicationContext.xml");
    	
    	Employee e= context.getBean("empObj",Employee.class);
    	
    	System.out.println("Employee details are : ");
    	System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
    	
        System.out.println("Constructor inject from product");
    	Product pobj= context.getBean("prodObj",Product.class);
    	System.out.println("Product Details are :");
    	System.out.println("productID is : "+pobj.getProductId());
    	System.out.println("ProductName is : "+pobj.getProductName());
    	System.out.println("Price is "+pobj.getPrice());
    	
    	
    	
    	
    }
}
