package com.training.exception;

public class Calculation {
	public static void main(String[] args) {

		System.out.println("statement 1");
	    try {
	    int a=10/0;
	    
	    System.out.println(a);
	    }catch(ArithmeticException e) {
	    	//e.printStackTrace();
	    	//System.out.println(e.getMessage());
	    	System.err.println("Denominator cannot be zero ");
	    }finally {
	    	System.out.println("we are in finally ");
	    }
	    
	    System.out.println("statement2");

	}
}
