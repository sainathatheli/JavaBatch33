package com.training.config;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.bean.Product;

@Configuration
public class AppConfig {

	//Collection injection with help of setters
	
	@Bean(name="pobj")
	public Product pdtObj() {
	Product p = new Product();
	p.setData(lstData());
	p.setModels(setData());
	p.setModes(mapData());
	p.setContext(propsData());
	return p;
	}
	public List<String> lstData(){
	List<String>lst = new LinkedList<>();
	lst.add("PEN");
	lst.add("PENCIL");
	return lst;
	}
	public Set<String> setData(){
	Set<String>set = new HashSet<>();
	set.add("CAR");
	set.add("BYKE");
	return set;
	}
	public Map<Integer , String> mapData(){
	Map<Integer , String>map = new LinkedHashMap<>();
	map.put(10, "TV");
	map.put(20, "LACTOP");
	map.put(30, "MOBILE");
	return map;
	}

	public Properties propsData() {
	Properties p = new Properties();
	p.put(1 , "AC");
	p.put(2, "COOLER");
	return p;
	}
	}

	