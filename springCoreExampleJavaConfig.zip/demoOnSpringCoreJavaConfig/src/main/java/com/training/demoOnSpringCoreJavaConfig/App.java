package com.training.demoOnSpringCoreJavaConfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.bean.Employee;
import com.training.bean.Product;
import com.training.configuration.JavaConfig;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    	ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
    	
    	Employee  e =context.getBean("empJavaConfig",Employee.class);
    	
    	System.out.println("Employee Details are using SpringCoreJavaConfigration class:");
    	System.out.println("Employee Id : "+e.getEmpId());
    	System.out.println("EMployee  name "+e.getEmpName());
    	System.out.println("EMployee  name "+e.getEmpSal());
    	
    	System.out.println("Product  Details are using SpringCoreJavaConfigration class:");
    	 System.out.println("Constructor inject from product");
     	Product pobj= context.getBean("prodObj",Product.class);
     	System.out.println("Product Details are :");
     	System.out.println("productID is : "+pobj.getProductId());
     	System.out.println("ProductName is : "+pobj.getProductName());
     	System.out.println("Price is "+pobj.getPrice());
    	
    	
    }
}
