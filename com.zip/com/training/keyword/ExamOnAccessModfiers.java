package com.training.keyword;

public class ExamOnAccessModfiers {
     int a=10;
     private int b = 20;
     protected String name="XYZ";
     public float pi=3.142f;
     
    void methodOne() {
    	System.out.println("we are in default method");
    }     
	
    private void methodTwo() {
    	System.out.println("we are in private method");
    }  
	
    protected void methodThree() {
    	System.out.println("we are in protected method");
    }  
    
   public void methodFour() {
    	System.out.println("we are in public method");
    }  
   
	/*
	 * public static void main(String[] args) { ExamOnAccessModfiers eoaf = new
	 * ExamOnAccessModfiers(); System.out.println(eoaf.a);
	 * System.out.println(eoaf.b); System.out.println(eoaf.name);
	 * System.out.println(eoaf.pi);
	 * 
	 * eoaf.methodOne(); eoaf.methodTwo(); eoaf.methodThree(); eoaf.methodFour();
	 * 
	 * 
	 * }
	 */
	 
    
}

